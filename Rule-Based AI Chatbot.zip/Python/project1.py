import string
import sys

class ChatbotEngine:
    """A professional-grade chatbot logic engine."""
    
    def __init__(self):
        self._responses = {
            'hello': "Welcome to DecodeLabs! How can I assist with your project?",
            'hi': "Hello! Ready to build some guardrails today?",
            'how are you': "I'm operating within perfect parameters, thanks for asking!",
            'project 1': "Project 1 is about mastering Control Flow and Logic via if-else statements.",
            'what is an llm': "An LLM is a probabilistic core that needs deterministic guardrails to be safe.",
            'help': "I can answer questions about 'Project 1', 'LLMs', or just say 'hello'!"
        }
        self.default_response = "I am not programmed for that input yet. Please check the documentation."


    def _preprocess_input(self, text: str) -> str:
        """Cleans and standardizes user input."""
        
        translator = str.maketrans('', '', string.punctuation)
        return text.lower().translate(translator).strip()

    def get_response(self, user_input: str) -> str:
        """Retrieves the appropriate response based on processed input."""
        processed = self._preprocess_input(user_input)
        return self._responses.get(processed, self.default_response)

    def run(self):
        """Starts the main interaction loop."""
        print("--- DecodeLabs Logic Engine v1.1 Initialized ---")
        print("Type 'exit' to terminate the session.")
        
        try:
            while True:
                user_input = input('\nProgrammer: ').strip()
                
                if user_input.lower() == 'exit':
                    print("Chatbot: Logic engine shutting down. Goodbye!")
                    break
                
                response = self.get_response(user_input)
                print(f"Chatbot: {response}")
        except EOFError:
            
            print("\nChatbot: Session terminated unexpectedly. Goodbye!")

if __name__ == "__main__":
    bot = ChatbotEngine()
    bot.run()